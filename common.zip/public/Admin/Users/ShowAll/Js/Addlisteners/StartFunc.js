import { StartFunc as StartFuncImageShowButon } from "./ImageShowButon/StartFunc.js";

let StartFunc = () => {
    StartFuncImageShowButon();
};

export { StartFunc };